import { type ExtendedRecordMap } from 'notion-types'

import { getBlockTitle } from './get-block-title'
import { getBlockValue } from './get-block-value'
import { getPageProperty } from './get-page-property'
import { normalizeTitle } from './normalize-title'
import { uuidToId } from './uuid-to-id'

/**
 * Gets the canonical, display-friendly version of a page's ID for use in URLs.
 */
export const getCanonicalPageId = (
  pageId: string,
  recordMap: ExtendedRecordMap,
  { uuid = true }: { uuid?: boolean } = {}
): string | null => {
  if (!pageId || !recordMap) return null

  const id = uuidToId(pageId)
  const block = getBlockValue(recordMap.block[pageId])

  if (block) {
    const slug =
      (getPageProperty('slug', block, recordMap) as string | null) ||
      (getPageProperty('Slug', block, recordMap) as string | null) ||
      normalizeTitle(getBlockTitle(block, recordMap))

    if (slug) {
      if (uuid) {
        return `${slug}-${id}`
      } else {
        return slug
      }
    }
  }

  return id
}
